/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  */
#include <string.h>
#include "board.h"
#include "hal_key.h"
#include "tim-board.h"
#include "timer_handles.h"


void Init() {
    BoardInitMcu();
    BoardInitPeriph();
    keys_init();//������ʼ��
    setTimer2Callback(Time2Handler);
    Tim2McuInit(1);//��ʱ����ʼ�������ö�ʱ�ж�1ms�ж�һ��
}



/**
 * Main application entry point.
 */
int main( void )
{
    Init();
    OLED_Init();
    OLED_Clear();
    OLED_ShowString(0, 0, (uint8_t *)"Hello LoRa!");
    OLED_ShowNum(0, 2, 20250206, 8, 16);
    while( 1 )
    {
			
    }
}
